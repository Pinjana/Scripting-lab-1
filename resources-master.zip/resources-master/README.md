## To run the solution on your system, download this repo on your computer, open that downloaded folder in a new VSCode window and type `npm install` in your terminal. 

**Note** ***: The `npm install` command will only work in a javascript or a typecript project that has a `package.json` file***

You can check out the solutions' output by typing `node solution.js` in the terminal of that downloaded repos' folder
<!-- # List of links
```javascript
const memeLinksArray = [
  "https://i.redd.it/i4e5bpo46ru91.jpg",
  "https://i.redd.it/u1obzkdc6ru91.jpg",
  "https://i.redd.it/jcnm0ppo6ru91.jpg",
  "https://i.redd.it/50v8ylma7ru91.png",
  "https://i.redd.it/dyiiwkkh7ru91.jpg",
  "https://i.redd.it/4hcjw2yy7ru91.jpg",
  "https://i.redd.it/wsq6ruc68ru91.jpg",
  "https://i.redd.it/hhp44yqh8ru91.jpg",
  "https://i.redd.it/xo43xjfo8ru91.jpg",
  "https://i.redd.it/vbla1hnu8ru91.jpg",
  "https://i.redd.it/thgop1b19ru91.jpg",
  "https://i.redd.it/2hytizam9ru91.jpg",
  "https://i.redd.it/347c11lharu91.jpg",
  "https://i.redd.it/cy8s3a4qaru91.jpg",
  "https://i.redd.it/5mxs4a61bru91.jpg",
  "https://i.redd.it/kd3jv2lfbru91.jpg",
  "https://i.redd.it/jfu7879qbru91.jpg",
  "https://i.redd.it/u8ddlnczbru91.jpg",
  "https://i.redd.it/59cc3t09cru91.jpg",
  "https://i.redd.it/a2qd2g9fcru91.jpg",
  "https://i.redd.it/ca10084lcru91.jpg",
  "https://i.redd.it/mxlb1j47dru91.jpg",
  "https://i.redd.it/x4nv3ebmdru91.jpg",
  "https://i.redd.it/ozkhmp4sdru91.jpg",
  "https://i.redd.it/871jikc0eru91.jpg",
  "https://i.redd.it/4zr9qbmaeru91.jpg",
  "https://i.redd.it/d7r7ap9oeru91.png",
  "https://i.redd.it/mtdvdey7fru91.jpg",
  "https://i.redd.it/qa0duhk9gru91.jpg"
];


``` -->
